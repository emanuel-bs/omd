<?php defined('SYSPATH') OR die('No direct access allowed.');

// E_STRICT is deprecated starting with php 8.4
$E_STRICT = PHP_VERSION_ID < 80400 ? E_STRICT : 2048;

$lang = array
(
	E_KOHANA             => array( 1, 'Framework Error',   'Please check the Kohana documentation for information about the following error.'),
	E_PAGE_NOT_FOUND     => array( 1, 'Page Not Found',    'The requested page was not found. It may have moved, been deleted, or archived.'),
	E_DATABASE_ERROR     => array( 1, 'Database Error',    'A database error occurred while performing the requested procedure. Please review the database error below for more information.'),
	E_ERROR              => array( 1, 'Fatal Error',       ''),
	E_USER_ERROR         => array( 1, 'Fatal Error',       ''),
	E_PARSE              => array( 1, 'Syntax Error',      ''),
	E_WARNING            => array( 1, 'Warning Message',   ''),
	E_USER_WARNING       => array( 1, 'Warning Message',   ''),
	$E_STRICT            => array( 2, 'Strict Mode Error', ''),
	E_NOTICE             => array( 2, 'Runtime Message',   ''),
);
