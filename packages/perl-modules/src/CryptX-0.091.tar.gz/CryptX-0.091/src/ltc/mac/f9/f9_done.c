/* LibTomCrypt, modular cryptographic library -- Tom St Denis */
/* SPDX-License-Identifier: Unlicense */
#include "tomcrypt_private.h"

/**
  @file f9_done.c
  f9 Support, terminate the state
*/

#ifdef LTC_F9_MODE

/** Terminate the f9-MAC state
  @param f9     f9 state to terminate
  @param out      [out] Destination for the MAC tag
  @param outlen   [in/out] Destination size and final tag size
  Return CRYPT_OK on success
*/
int f9_done(f9_state *f9, unsigned char *out, unsigned long *outlen)
{
   int err, x;
   LTC_ARGCHK(f9 != NULL);
   LTC_ARGCHK(out  != NULL);

   /* check structure */
   if ((err = cipher_is_valid(f9->cipher)) != CRYPT_OK) {
      return err;
   }

   if ((f9->blocksize > cipher_descriptor[f9->cipher].block_length) || (f9->blocksize < 0) ||
       (f9->buflen > f9->blocksize) || (f9->buflen < 0)) {
      return CRYPT_INVALID_ARG;
   }

   if (f9->buflen != 0) {
      /* encrypt */
      ecb_encrypt_block(f9->IV, f9->IV, &f9->key);
      f9->buflen = 0;
      for (x = 0; x < f9->blocksize; x++) {
         f9->ACC[x] ^= f9->IV[x];
      }
   }

   /* schedule modified key */
   if ((err = ecb_start(f9->cipher, f9->akey, f9->keylen, 0, &f9->key)) != CRYPT_OK) {
      return err;
   }

   /* encrypt the ACC */
   ecb_encrypt_block(f9->ACC, f9->ACC, &f9->key);
   ecb_done(&f9->key);

   /* extract tag */
   for (x = 0; x < f9->blocksize && (unsigned long)x < *outlen; x++) {
      out[x] = f9->ACC[x];
   }
   *outlen = x;

#ifdef LTC_CLEAN_STACK
   zeromem(f9, sizeof(*f9));
#endif
   return CRYPT_OK;
}

#endif

