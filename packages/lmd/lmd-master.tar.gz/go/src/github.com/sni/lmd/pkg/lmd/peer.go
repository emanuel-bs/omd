package lmd

import (
	"bufio"
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"regexp"
	"runtime/debug"
	"runtime/trace"
	"slices"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

var (
	reResponseHeader = regexp.MustCompile(`^(\d+)\s+(\d+)$`)
	reHTTPTooOld     = regexp.MustCompile(`Can.t locate object method`)
	reHTTPOMDError   = regexp.MustCompile(`<h1>(OMD:.*?)</h1>`)
	reHTTPThrukError = regexp.MustCompile(`(?sm)<!--error:(.*?):error-->`)
	reShinkenVersion = regexp.MustCompile(`\-shinken$`)
	reIcinga2Version = regexp.MustCompile(`^(r[\d.-]+|.*\-icinga2)$`)
	reNaemonVersion  = regexp.MustCompile(`\-naemon$`)
	reThrukVersion   = regexp.MustCompile(`^(\d+\.\d+|\d+).*?$`)
)

const (
	// MinFullScanInterval is the minimum interval between two full scans.
	MinFullScanInterval = 60

	// UpdateLoopTickerInterval sets the interval for the peer to check if updates should be fetched.
	UpdateLoopTickerInterval = 300 * time.Millisecond

	// WaitTimeoutDefault sets the default timeout if nothing specified (1 minute in milliseconds).
	WaitTimeoutDefault = 60000

	// WaitTimeoutCheckInterval set interval in which wait condition is checked.
	WaitTimeoutCheckInterval = 200 * time.Millisecond

	// ErrorContentPreviewSize sets the number of bytes from the response to include in the error message.
	ErrorContentPreviewSize = 100

	// TemporaryNetworkErrorRetryDelay sets the sleep time for temporary network issue retries.
	TemporaryNetworkErrorRetryDelay = 500 * time.Millisecond

	// TemporaryNetworkErrorMaxRetries is the number of retries.
	TemporaryNetworkErrorMaxRetries = 3

	// Time after which a broken peer restarts.
	BrokenPeerGraceTimeSeconds = 300

	// Max size when logging the response of a query in errors.
	LogResponseErrorMaxSize = 10240 // 10kB

	// Max size of a JSON response in bytes.
	MaxJSONResponseSize = 5e9 // 5GB

	// Max size of a JSON meta response in bytes.
	MaxJSONMetaResponseSize = 1e6 // 1MB
)

// RowResultCB is a callback called for each result row.
type RowResultCB func(row []any, numBytes int) error

// Peer is the object which handles collecting and updating data and connections.
type Peer struct { //nolint:govet // not fieldalignment relevant
	noCopy          noCopy
	Name            string          // Name of this peer, aka peer_name
	ID              string          // ID for this peer, aka peer_key
	parentID        string          // ID of parent Peer
	peerParent      string          // peers parent ID
	section         string          // Section as defined in the peer config
	source          []string        // reference to all connection strings
	fallback        []string        // reference to all fallback connection strings
	stopChannel     chan bool       // channel to stop this peer
	waitGroup       *sync.WaitGroup // wait group used to wait on shutdowns
	lmd             *Daemon         // reference to main lmd instance
	config          *Connection     // reference to the peer configuration from the config file
	shutdownChannel chan bool       // channel used to wait to finish shutdown
	statusStore     *DataStore      // the cached pseudo store for the status table
	cacheLock       sync.Mutex      // protects cache.connectionPool from concurrent replacement
	cache           struct {
		HTTPClient             *http.Client  // cached http client for http backends
		connectionPool         chan net.Conn // tcp connection get stored here for reuse
		maxParallelConnections chan bool     // limit max parallel connections
	}
	// volatile status attributes
	data                       atomic.Pointer[DataStoreSet]   // the cached remote data tables
	peerState                  atomicPeerStatus               // status for this peer
	peerAddr                   atomicString                   // Address of the peer
	lastError                  atomicString                   // last error message
	subPeerStatus              atomic.Pointer[map[string]any] // cached /sites result for sub peer
	configTool                 atomicString                   // raw json data of thruks config tool
	thrukExtras                atomicString                   // raw json bytes of thruk extra data
	programStart               atomic.Int64                   // unix time when this peer started, aka program_start
	curPeerAddrNum             atomic.Int64                   // current pointer into Source / Fallback
	bytesReceived              atomic.Int64                   // number of bytes received
	bytesSend                  atomic.Int64                   // number of bytes send
	corePid                    atomic.Int64                   // naemon core pid
	thrukVersion               atomicFloat64                  // thruks version number as float
	responseTime               atomicFloat64                  // response time in seconds
	lastOnline                 atomicFloat64                  // timestamp backend was last online
	queries                    atomic.Int64                   // number of total queries
	errorCount                 atomic.Int64                   // count times this backend has failed
	lastUpdate                 atomicFloat64                  // timestamp of last update
	lastFullUpdate             atomicFloat64                  // timestamp of last full update
	lastTimeperiodUpdateMinute atomic.Int32                   // minute when timeperiods last have been updated
	forceDelta                 atomic.Bool                    // flag to force next delta update
	forceComments              atomic.Bool                    // flag to force comments/downtimes update on next periodic check
	restv1FullDelta            atomic.Bool                    // flag to force a full delta after a command on Icinga2 RESTv1 backends

	flags                     uint32           // optional flags, like LMD, Icinga2, etc...
	lastQuery                 atomicFloat64    // unix timestamp of last query
	lastHTTPRequestSuccessful atomic.Bool      // flag wether last http request was ok
	paused                    atomic.Bool      // flag wether peer is paused of not
	idling                    atomic.Bool      // flag wether peer is in idle mode
	errorLogged               atomic.Bool      // flag wether last error has been logged already
	subName                   atomicStringList // chain of peer names to this sub peer
	subType                   atomicStringList // chain of peer types to this sub peer
	subAddr                   atomicStringList // chain of peer addresses to this sub peer
	subKey                    atomicStringList // chain of peer keys to this sub peer
	subVersion                atomicStringList // chain of peer versions to this sub peer
	last                      struct {
		Request  atomic.Pointer[Request] // reference to last query (used in error reports)
		Response atomic.Pointer[[]byte]  // reference to last response
	}
}

var connectionErrorIndicators = [][]byte{
	[]byte("No UNIX socket /"),
	[]byte("Couldn't connect"),
}

// PeerStatus contains the different states a peer can have.
type PeerStatus int32

// A peer can be up, warning, down and pending.
// It is pending right after start and warning when the connection fails
// but the stale timeout is not yet hit.
const (
	PeerStatusUp      PeerStatus = iota // peer is up and running and fully synced
	PeerStatusWarning                   // peer is down but stale timeout has not yet reached
	PeerStatusDown                      // peer is down and cached data removed
	PeerStatusBroken                    // broken flags clients which cannot be used, lmd will check program_start and only retry them if start time changed
	PeerStatusPending                   // initial status on startup
	PeerStatusSyncing                   // sync started and first data set but not yet finished
)

// String converts a PeerStatus into a string.
func (ps *PeerStatus) String() string {
	switch *ps {
	case PeerStatusUp:
		return "up"
	case PeerStatusWarning:
		return "warning"
	case PeerStatusDown:
		return "down"
	case PeerStatusBroken:
		return "broken"
	case PeerStatusPending:
		return "pending"
	case PeerStatusSyncing:
		return "syncing"
	default:
		log.Panicf("not implemented")
	}

	return ""
}

// PeerErrorType is used to distinguish between connection and response errors.
type PeerErrorType uint8

const (
	// ConnectionError is used when the connection to a remote site failed.
	ConnectionError PeerErrorType = iota

	// ResponseError is used when the remote site is available but returns an unusable result.
	ResponseError

	// RestartRequiredError is used when the remote site needs to be reinitialized.
	RestartRequiredError
)

// HTTPResult contains the livestatus result as long with some meta data.
type HTTPResult struct {
	Version string          `json:"version"`
	Branch  string          `json:"branch"`
	Message string          `json:"message"`
	Output  json.RawMessage `json:"output"`
	Raw     []byte          `json:"raw"`
	Rc      int             `json:"rc"`
	Code    int             `json:"code"`
}

// PeerError is a custom error to distinguish between connection and response errors.
type PeerError struct {
	srcErr   error
	req      *Request
	msg      string
	res      [][]any
	resBytes []byte
	code     int
	kind     PeerErrorType
}

// Error returns the error message as string.
func (e *PeerError) Error() string {
	msg := e.msg
	if msg == "EOF" {
		return msg
	}

	if e.req != nil {
		msg += fmt.Sprintf("\nRequest: %s", e.req.String())
	}
	if e.res != nil {
		msg += fmt.Sprintf("\nResponse: %#v", e.res)
	}
	if e.resBytes != nil {
		msg += fmt.Sprintf("\nResponse: %s", string(e.resBytes))
	}

	return msg
}

// Type returns the error type.
func (e *PeerError) Type() PeerErrorType { return e.kind }

// PeerCommandError is a custom error when remote site returns something after sending a command.
type PeerCommandError struct {
	err  error
	peer *Peer
	code int
}

// Error returns the error message as string.
func (e *PeerCommandError) Error() string {
	str := strings.TrimPrefix(e.err.Error(), fmt.Sprintf("%d: ", e.code))

	if e.code == 0 {
		return str
	}

	return fmt.Sprintf("%d: %s", e.code, str)
}

// NewPeer creates a new peer object.
// It returns the created peer.
//
//nolint:contextcheck,nolintlint // need new context, peer is a independent object
func NewPeer(lmd *Daemon, config *Connection) *Peer {
	peer := &Peer{
		Name:            config.Name,
		ID:              config.ID,
		source:          config.Source,
		fallback:        config.Fallback,
		section:         config.Section,
		waitGroup:       lmd.waitGroupPeers,
		shutdownChannel: lmd.shutdownChannel,
		stopChannel:     make(chan bool),
		config:          config,
		lmd:             lmd,
		flags:           uint32(NoFlags),
	}
	peer.cache.connectionPool = make(chan net.Conn, lmd.Config.MaxParallelPeerConnections)
	peer.cache.maxParallelConnections = make(chan bool, lmd.Config.MaxParallelPeerConnections)

	if len(peer.source) == 0 {
		logWith(&peer).Fatalf("peer requires at least one source")
	}

	peer.thrukVersion.Set(-1)
	peer.peerAddr.Set(config.Source[0])
	peer.lastError.Set("connecting...")
	peer.paused.Store(true)
	peer.peerState.Set(PeerStatusPending)
	peer.subKey.Set([]string{})
	peer.subName.Set([]string{})
	peer.subAddr.Set([]string{})
	peer.subType.Set([]string{})
	peer.subVersion.Set([]string{})

	/* initialize http client if there are any http(s) connections */
	peer.setHTTPClient()

	peer.statusStore = BuildTableBackendsStore(context.Background(), Objects.Tables[TableStatus], peer)

	peer.resetFlags()

	return peer
}

// Start creates the initial objects and starts the update loop in a separate goroutine.
func (p *Peer) Start(ctx context.Context) {
	if !p.paused.Load() {
		logWith(p).Panicf("tried to start updateLoop twice")
	}
	p.waitGroup.Add(1)
	p.paused.Store(false)
	logWith(p).Infof("starting connection")
	go func(peer *Peer, wGroup *sync.WaitGroup) {
		// make sure we log panics properly
		defer logPanicExitPeer(peer)
		// always release the wait group and unpause, even if updateLoop panics,
		// otherwise the peer would be stuck forever and could never be restarted
		defer func() {
			p.paused.Store(true)
			wGroup.Done()
		}()
		peer.updateLoop(ctx)
	}(p, p.waitGroup)
}

// Stop stops this peer. Restart with Start.
func (p *Peer) Stop() {
	if p.paused.Load() {
		return
	}
	logWith(p).Infof("stopping connection")
	p.stopChannel <- true
}

// Query sends a livestatus request from a request object.
// It calls query and logs all errors except connection errors which are logged in GetConnection.
// It returns the livestatus result and any error encountered.
func (p *Peer) Query(ctx context.Context, req *Request) (result ResultSet, meta *ResultMetaData, err error) {
	result, meta, err = p.query(ctx, req)
	if err != nil {
		p.setNextAddrFromErr(err, req, p.source)
	}

	return result, meta, err
}

// QueryCB sends a livestatus request from a request object.
// It returns the meta data and any error encountered.
// Callback is called for each data row.
// Only works for queries which return arrays of arrays.
func (p *Peer) QueryCB(ctx context.Context, req *Request, clb RowResultCB) (meta *ResultMetaData, err error) {
	if clb == nil {
		return nil, fmt.Errorf("callback is required")
	}
	if req.Command != "" {
		return nil, fmt.Errorf("callback queries are not supported for commands")
	}
	if req.OutputFormat != OutputFormatJSON {
		return nil, fmt.Errorf("callback queries are only supported for normal json output format")
	}

	_, meta, err = p.queryCB(ctx, req, clb)
	if err != nil {
		p.setNextAddrFromErr(err, req, p.source)
	}

	return meta, err
}

// QueryString sends a livestatus request from a given string.
// It returns the livestatus result and any error encountered.
func (p *Peer) QueryString(str string) (ResultSet, *ResultMetaData, error) {
	ctx := context.WithValue(context.Background(), CtxPeer, p.Name)

	return p.QueryContext(ctx, str)
}

// QueryContext sends a livestatus request from a given string.
// It returns the livestatus result and any error encountered.
func (p *Peer) QueryContext(ctx context.Context, str string) (ResultSet, *ResultMetaData, error) {
	ctx = context.WithValue(ctx, CtxPeer, p.Name)
	req, _, err := NewRequest(ctx, p.lmd, bufio.NewReader(bytes.NewBufferString(str)), ParseDefault)
	if err != nil {
		if errors.Is(err, io.EOF) {
			err = errors.New("bad request: empty request")

			return nil, nil, err
		}

		return nil, nil, err
	}

	return p.Query(ctx, req)
}

// SendCommands sends list of commands.
func (p *Peer) SendCommands(ctx context.Context, commands []string) error {
	commandRequest := &Request{
		Command: strings.Join(commands, "\n\n"),
	}
	ctx = context.WithValue(ctx, CtxRequest, commandRequest.ID())
	p.setQueryOptions(commandRequest)
	_, _, err := p.Query(ctx, commandRequest)
	if err != nil {
		if peerCmdErr, ok := errors.AsType[*PeerCommandError](err); ok {
			logWith(ctx).Debugf("sending command failed (invalid query) - %d: %s", peerCmdErr.code, peerCmdErr.Error())
		} else {
			logWith(ctx).Warnf("sending command failed: %s", err.Error())
		}

		return err
	}
	logWith(ctx).Infof("send %d commands successfully.", len(commands))

	p.scheduleImmediateUpdate()
	if p.hasFlag(HasLastUpdateColumn) {
		// check if comments or downtimes need to be refreshed
		if commandsAffectCommentsOrDowntimes(commands) {
			p.scheduleImmediateComDownUpdate()
		}
	}

	return nil
}

// setHTTPClient creates the cached http client (if backend uses HTTP).
func (p *Peer) setHTTPClient() {
	hasHTTP := false
	for _, addr := range p.source {
		if strings.HasPrefix(addr, "http") {
			hasHTTP = true

			break
		}
	}
	for _, addr := range p.fallback {
		if strings.HasPrefix(addr, "http") {
			hasHTTP = true

			break
		}
	}
	if !hasHTTP {
		return
	}

	tlsConfig, err := p.getTLSClientConfig()
	if err != nil {
		logWith(p).Fatalf("failed to initialize peer: %s", err.Error())
	}
	client := NewLMDHTTPClient(tlsConfig, p.config.Proxy)
	client.Timeout = time.Duration(p.lmd.Config.NetTimeout) * time.Second

	logWith(p).Debugf("set new http client cache")
	p.cache.HTTPClient = client
}

// updateLoop is the main loop updating this peer.
// It does not return till triggered by the shutdownChannel or by the internal stopChannel.
func (p *Peer) updateLoop(ctx context.Context) {
	err := p.initAllTables(ctx)
	if err != nil {
		if !p.errorLogged.Load() {
			logWith(p).Infof("initializing objects failed: %s", err.Error())
			p.errorLogged.Store(true)
		}
	}

	shutdownStop := func(peer *Peer, ticker *time.Ticker) {
		logWith(peer).Debugf("stopping...")
		ticker.Stop()
		peer.clearLastRequest()
	}

	var lastErr error
	ticker := time.NewTicker(UpdateLoopTickerInterval)
	for {
		var loopErr error
		var ok bool
		time1 := time.Now()
		select {
		case <-p.shutdownChannel:
			shutdownStop(p, ticker)

			return
		case <-p.stopChannel:
			shutdownStop(p, ticker)

			return
		case <-ticker.C:
			ok, loopErr = p.tryUpdate(ctx)
		}
		duration := time.Since(time1)
		lastErr = p.initTablesIfRestartRequiredError(ctx, loopErr)
		if lastErr != nil {
			if !p.errorLogged.Load() {
				logWith(p).Infof("updating objects failed after: %s: %s", duration.String(), lastErr.Error())
				p.errorLogged.Store(true)
			} else {
				logWith(p).Debugf("updating objects failed after: %s: %s", duration.String(), lastErr.Error())
			}
		}
		if ok {
			p.clearLastRequest()
		}
	}
}

func (p *Peer) tryUpdate(ctx context.Context) (ok bool, err error) {
	time1 := time.Now()
	p.updateIdleStatus(p.idling.Load(), p.lastQuery.Get())

	ok, err = p.updateTick(ctx, false)
	if err != nil || !ok {
		return ok, err
	}

	duration := time.Since(time1)
	logWith(p).Debugf("delta update complete in: %s", duration.Truncate(time.Millisecond).String())

	p.resetErrors()
	p.responseTime.Set(duration.Seconds())

	promPeerUpdates.WithLabelValues(p.Name).Inc()
	promPeerUpdateDuration.WithLabelValues(p.Name).Set(duration.Seconds())

	return true, nil
}

// updateTick runs the periodic updates from the update loop.
func (p *Peer) updateTick(ctx context.Context, force bool) (ok bool, err error) {
	lastUpdate := p.lastUpdate.Get()
	lastFullUpdate := p.lastFullUpdate.Get()
	idling := p.idling.Load()
	forceDelta := p.forceDelta.Load() || force
	now := currentUnixTime()
	lastStatus := p.peerState.Get()
	data := p.data.Load()

	// run things unrelated to sync interval
	if lastStatus == PeerStatusUp && data != nil {
		err = data.sync.UpdateTick(ctx)
		if err != nil {
			return false, err
		}
	}

	var nextUpdate float64
	if idling {
		nextUpdate = lastUpdate + float64(p.lmd.Config.IdleInterval)
	} else {
		nextUpdate = lastUpdate + float64(p.lmd.Config.UpdateInterval)
	}
	if now < nextUpdate && !forceDelta {
		return false, nil
	}
	ok = true

	// set last update timestamp, otherwise we would retry the connection every couple of ms instead
	// of the update interval
	p.lastUpdate.Set(now)
	p.forceDelta.Store(false)

	switch lastStatus {
	case PeerStatusBroken:
		return false, p.handleBrokenPeer(ctx)
	case PeerStatusDown, PeerStatusPending:
		return ok, p.initAllTables(ctx)
	case PeerStatusWarning:
		if data == nil {
			logWith(p).Warnf("inconsistent state, no data with state: %s", lastStatus.String())

			return ok, p.initAllTables(ctx)
		}

		return true, data.updateDelta(ctx, lastUpdate, now)
	case PeerStatusUp, PeerStatusSyncing:
		if data == nil {
			logWith(p).Warnf("inconsistent state, no data with state: %s", lastStatus.String())

			return ok, p.initAllTables(ctx)
		}
		// full update interval
		if !idling && p.lmd.Config.FullUpdateInterval > 0 && now > lastFullUpdate+float64(p.lmd.Config.FullUpdateInterval) {
			return ok, data.updateFull(ctx)
		}

		return ok, data.updateDelta(ctx, lastUpdate, now)
	}

	logWith(p).Panicf("unhandled status case: %s", lastStatus.String())

	return ok, nil
}

// it fetches the sites table and creates and updates LMDSub backends for them.
func (p *Peer) handleBrokenPeer(ctx context.Context) (err error) {
	var res ResultSet
	res, _, err = p.QueryContext(ctx, "GET status\nOutputFormat: json\nColumns: program_start nagios_pid\n\n")
	if err != nil {
		logWith(p).Debugf("waiting for reload")

		return err
	}

	now := currentUnixTime()
	lastFullUpdate := p.lastFullUpdate.Get()
	if lastFullUpdate < now-float64(BrokenPeerGraceTimeSeconds) {
		logWith(p).Debugf("broken peer grace time over, trying again.")

		return p.initAllTables(ctx)
	}

	if len(res) > 0 && len(res[0]) == 2 {
		programStart := interface2int64(res[0][0])
		corePid := interface2int64(res[0][1])
		if p.programStart.Load() != programStart || p.corePid.Load() != corePid {
			logWith(p).Debugf("broken peer has reloaded, trying again.")

			return p.initAllTables(ctx)
		}

		return fmt.Errorf("waiting for peer to recover: program_start: %s (%d)  - pid: %d", time.Unix(programStart, 0).String(), programStart, corePid)
	}

	return fmt.Errorf("unknown result while waiting for peer to recover: %v", res)
}

func (p *Peer) removeExceedingSubPeers(existing map[string]bool) {
	// remove exceeding peers
	removePeers := []string{}

	for _, peer := range p.lmd.peerMap.Peers() {
		if peer.parentID == p.ID {
			if _, ok2 := existing[peer.ID]; !ok2 {
				logWith(peer).Debugf("removing sub peer")
				removePeers = append(removePeers, peer.ID)
				peer.Stop()
				peer.data.Store(nil)
			}
		}
	}
	p.lmd.peerMap.Remove(removePeers...)
}

func (p *Peer) updateIdleStatus(idling bool, lastQuery float64) bool {
	now := currentUnixTime()
	shouldIdle := false
	if lastQuery == 0 && p.lmd.lastMainRestart < now-float64(p.lmd.Config.IdleTimeout) {
		shouldIdle = true
	} else if lastQuery > 0 && lastQuery < now-float64(p.lmd.Config.IdleTimeout) {
		shouldIdle = true
	}
	if !idling && shouldIdle {
		logWith(p).Infof("switched to idle interval, last query: %s (idle timeout: %d)", timeOrNever(lastQuery), p.lmd.Config.IdleTimeout)
		p.idling.Store(true)
		idling = true
	}

	return idling
}

func (p *Peer) initTablesIfRestartRequiredError(ctx context.Context, err error) error {
	if err == nil {
		return nil
	}
	if peerErr, ok := errors.AsType[*PeerError](err); ok {
		if peerErr.kind == RestartRequiredError {
			return p.initAllTables(ctx)
		}
	}

	return err
}

func (p *Peer) scheduleUpdateIfRestartRequiredError(err error) bool {
	if err == nil {
		return false
	}
	if peerErr, ok := errors.AsType[*PeerError](err); ok {
		if peerErr.kind == RestartRequiredError {
			p.scheduleImmediateUpdate()

			return true
		}
	}

	return false
}

// countQuery returns the result of a stats query or -1 if nothing found.
func (p *Peer) countQuery(ctx context.Context, name, queryCondition string) (count int) {
	res, _, err := p.QueryContext(ctx, "GET "+name+"\nOutputFormat: json\nStats: "+queryCondition+"\n\n")
	if err == nil && len(res) > 0 && len(res[0]) > 0 {
		return interface2int(res[0][0])
	}

	return -1
}

// scheduleImmediateUpdate resets all update timer so the next update loop iteration
// will perform an update.
func (p *Peer) scheduleImmediateUpdate() {
	p.forceDelta.Store(true)
}

// scheduleImmediateComDownUpdate resets comment / downtimes update timer so the
// next update loop iteration will perform an update.
func (p *Peer) scheduleImmediateComDownUpdate() {
	p.forceComments.Store(true)
}

// initAllTables creates all tables for this peer.
// It returns true if the import was successful or false otherwise.
func (p *Peer) initAllTables(ctx context.Context) (err error) {
	defer trace.StartRegion(ctx, "initAllTables").End()
	time1 := time.Now()

	logWith(p).Debugf("starting initial objects synchronization")
	data := NewDataStoreSet(p)
	err = data.initAllTables(ctx)
	if err != nil {
		return err
	}

	err = p.requestLocaltime(ctx)
	if err != nil {
		return err
	}

	duration := time.Since(time1)
	peerStatus := p.peerState.Get()
	p.data.Store(data)
	p.responseTime.Set(duration.Seconds())
	logWith(p).Infof("initial objects synchronized in: %s", duration.String())
	if peerStatus != PeerStatusUp {
		p.resetErrors()
	}

	promPeerUpdates.WithLabelValues(p.Name).Inc()
	promPeerUpdateDuration.WithLabelValues(p.Name).Set(duration.Seconds())

	p.clearLastRequest()

	return nil
}

// updateInitialStatus updates peer meta data from last status request.
func (p *Peer) updateInitialStatus(ctx context.Context, store *DataStore) (err error) {
	statusData := store.data
	hasStatus := len(statusData) > 0
	// this may happen if we query another lmd daemon which has no backends ready yet
	if !hasStatus {
		p.peerState.Set(PeerStatusDown)
		p.lastError.Set("peered partner not ready yet")
		p.data.Store(nil)

		return fmt.Errorf("peered partner not ready yet")
	}

	// if its http and a status request, try a processinfo query to fetch all backends
	configtool, thrukExtras, cErr := p.fetchThrukExtras(ctx) // this also sets the thruk version and checks the clock, so it should be called first
	if cErr != nil {
		// log error, but this should not prevent accessing the backend
		log.Debugf("fetchThrukExtras: %s ", cErr.Error())
	}
	if p.config.NoConfigTool >= 1 {
		configtool = map[string]any{
			"disable": "1",
		}
		if thrukExtras == nil {
			thrukExtras = map[string]any{}
		}
		thrukExtras["configtool"] = configtool
	}
	p.logErrors(p.fetchRemotePeers(ctx, store.dataSet))
	p.logErrors(p.checkStatusFlags(ctx, store.dataSet))

	err = p.checkAvailableTables(ctx) // must be done after checkStatusFlags, because it does not work on Icinga2
	if err != nil {
		return err
	}

	store.dataSet.setSyncStrategy()

	programStart := statusData[0].GetInt64ByName("program_start")
	corePid := statusData[0].GetInt64ByName("nagios_pid")

	// check thruk config tool settings and other extra data
	p.configTool.Set("")
	p.thrukExtras.Set("")
	p.programStart.Store(programStart)
	p.corePid.Store(corePid)
	if !p.hasFlag(MultiBackend) {
		// store as string, we simply passthrough it anyway
		if configtool != nil {
			val := interface2JSONString(configtool)
			p.configTool.Set(val)
		}
		if thrukExtras != nil {
			val := interface2JSONString(thrukExtras)
			p.thrukExtras.Set(val)
		}
	}

	return nil
}

// resetErrors reset the error counter after the site has recovered.
func (p *Peer) resetErrors() {
	prevPeerStatus := p.peerState.Get()
	p.lastError.Set("")
	p.lastOnline.Set(currentUnixTime())
	p.errorCount.Store(0)
	p.errorLogged.Store(false)
	p.peerState.Set(PeerStatusUp)

	if prevPeerStatus == PeerStatusDown {
		logWith(p).Infof("site is back online")
	}
}

// query sends the request to a remote livestatus.
// It returns the unmarshaled result and any error encountered.
func (p *Peer) query(ctx context.Context, req *Request) (ResultSet, *ResultMetaData, error) {
	return p.queryCB(ctx, req, nil)
}

// query sends the request to a remote livestatus.
// It returns the unmarshaled result and any error encountered.
// The callback is optional. If set, instead of a result set, each result row will be send to the callback.
func (p *Peer) queryCB(ctx context.Context, req *Request, clb RowResultCB) (ResultSet, *ResultMetaData, error) {
	p.cache.maxParallelConnections <- true // wait/reserve one connection slot, channel will block if full

	var conn net.Conn
	var connType ConnectionType
	var err error
	defer func() {
		switch {
		case conn == nil:
		case req.KeepAlive:
			// give back connection
			if err == nil {
				logWith(p, req).Tracef("put connection back into pool")
				p.putCachedConnection(conn)
			} else {
				p.putCachedConnection(nil)
			}
		default:
			conn.Close()
		}
		<-p.cache.maxParallelConnections // free one connection slot
	}()

	// add backends filter for lmd sub peers
	if p.hasFlag(LMDSub) {
		req.Backends = []string{p.ID}
	}

	logWith(p, req).Tracef("connection #%02d of max. %02d", len(p.cache.maxParallelConnections), p.lmd.Config.MaxParallelPeerConnections)

	conn, connType, err = p.GetConnection(req)
	if err != nil {
		logWith(p, req).Tracef("query: %s", req.String())
		logWith(p, req).Debugf("connection failed: %s", err)

		return nil, nil, err
	}
	if connType == ConnTypeHTTP {
		req.KeepAlive = false
	}
	// icinga2 RESTv1 backends speak the REST API, not the livestatus protocol
	if p.hasFlag(Icinga2RestV1) {
		return p.icinga2RestV1Query(ctx, req, clb)
	}
	query := req.String()
	if log.IsV(LogVerbosityTrace) {
		logWith(p, req).Tracef("query: %s", query)
	}

	if p.lmd.Config.SaveTempRequests {
		p.last.Request.Store(req)
		p.last.Response.Store(nil)
	}
	p.queries.Add(1)
	totalBytesSend := p.bytesSend.Add(int64(len(query)))
	peerAddr := p.peerAddr.Get()
	promPeerBytesSend.WithLabelValues(p.Name).Set(float64(totalBytesSend))
	promPeerQueries.WithLabelValues(p.Name).Inc()

	if clb != nil {
		t1 := time.Now()
		newConn, bErr := p.getQueryResponseCB(ctx, req, query, peerAddr, conn, connType, clb)
		if bErr != nil {
			logWith(p, req).Debugf("backend query failed: %w", bErr)

			return nil, nil, bErr
		}
		if newConn != nil {
			conn = newConn
		}
		meta := ResultMetaData{
			Request:  req,
			Duration: time.Since(t1),
		}

		return nil, &meta, nil
	}

	// no callback set, parse regularly
	t1 := time.Now()
	resBytes, newConn, err := p.getQueryResponse(ctx, req, query, peerAddr, conn, connType)
	duration := time.Since(t1)
	if err != nil {
		logWith(p, req).Debugf("backend query failed: %w", err)

		return nil, nil, err
	}
	if newConn != nil {
		conn = newConn
	}
	if req.Command != "" {
		resBytes = bytes.TrimSpace(resBytes)
		if len(resBytes) > 0 {
			return nil, nil, p.parseCommandErrResponse(string(resBytes))
		}

		return nil, nil, nil
	}

	if log.IsV(LogVerbosityTrace) {
		logWith(p, req).Tracef("result: %s", string(resBytes))
	}
	if p.lmd.Config.SaveTempRequests {
		p.last.Response.Store(&resBytes)
	}
	totalBytesReceived := p.bytesReceived.Add(int64(len(resBytes)))
	promPeerBytesReceived.WithLabelValues(p.Name).Set(float64(totalBytesReceived))

	data, meta, err := req.parseResult(ctx, resBytes)
	if err != nil {
		logWith(p, req).Errorf("fetching table failed %20s time: %s, size: %d kB", req.Table.String(), duration, len(resBytes)/1024)
		p.logJSONRequestParseErrorDetails(req, resBytes, err)

		return nil, nil, &PeerError{msg: err.Error(), kind: ResponseError, srcErr: err}
	}

	meta.Duration = duration
	meta.Size = len(resBytes)

	logWith(p, req).Tracef("fetched table: %15s - time: %8s - count: %8d - size: %8d kB", req.Table.String(), duration, len(data), len(resBytes)/1024)

	if duration > time.Duration(p.lmd.Config.LogSlowQueryThreshold)*time.Second {
		logWith(p, req).Warnf("slow backend query finished after %s, response size: %s\n%s", duration, byteCountBinary(int64(len(resBytes))), strings.TrimSpace(req.String()))
	}

	return data, meta, nil
}

func (p *Peer) logJSONRequestParseErrorDetails(req *Request, resBytes []byte, err error) {
	resStr := string(resBytes)
	if log.IsV(LogVerbosityDebug) {
		logWith(p, req).Debugf("result json string: %s", resStr)
	} else {
		if len(resStr) > LogResponseErrorMaxSize {
			resStr = resStr[:LogResponseErrorMaxSize]
			logWith(p, req).Errorf("result json string: %s", resStr)
			logWith(p, req).Errorf("result json string too long, truncated to %s", byteCountBinary(LogResponseErrorMaxSize))
		} else {
			logWith(p, req).Errorf("result json string: %s", resStr)
		}
	}
	logWith(p, req).Errorf("result parse error: %s", err.Error())
}

func (p *Peer) getQueryResponse(ctx context.Context, req *Request, query, peerAddr string, conn net.Conn, connType ConnectionType) ([]byte, net.Conn, error) {
	// http connections
	if connType == ConnTypeHTTP {
		return p.getHTTPQueryResponse(ctx, req, query, peerAddr, nil)
	}

	return p.getSocketQueryResponseWithTemporaryRetries(req, query, conn, nil)
}

func (p *Peer) getQueryResponseCB(ctx context.Context, req *Request, query, peerAddr string, conn net.Conn, connType ConnectionType, clb RowResultCB) (rConn net.Conn, err error) { //nolint:lll // long parameter list...
	// http connections
	switch connType {
	case ConnTypeHTTP:
		_, rConn, err = p.getHTTPQueryResponse(ctx, req, query, peerAddr, clb)
	default:
		_, rConn, err = p.getSocketQueryResponseWithTemporaryRetries(req, query, conn, clb)
	}

	return
}

func (p *Peer) getHTTPQueryResponse(ctx context.Context, req *Request, query, peerAddr string, clb RowResultCB) ([]byte, net.Conn, error) {
	res, _, err := p.httpQueryWithRetries(ctx, req, peerAddr, query, 2, clb)
	if err != nil {
		return nil, nil, err
	}
	if clb != nil {
		return nil, nil, nil
	}
	if req.ResponseFixed16 {
		code, expSize, err := parseResponseHeader(&res)
		if err != nil {
			logWith(p, req).Debugf("LastQuery:")
			logWith(p, req).Debugf("%s", req.String())

			return nil, nil, err
		}
		res = res[16:]

		err = p.validateResponseHeader(res, req, code, len(res), expSize)
		if err != nil {
			logWith(p, req).Debugf("LastQuery:")
			logWith(p, req).Debugf("%s", req.String())

			return nil, nil, err
		}
	}

	return res, nil, nil
}

func (p *Peer) getSocketQueryResponse(req *Request, query string, conn net.Conn, clb RowResultCB) ([]byte, error) {
	// tcp/unix connections
	n, err := p.socketSendQuery(query, conn)
	if err != nil {
		return nil, fmt.Errorf("connection error, send %d of %d bytes: %w", n, len(query), err)
	}

	// close write part of connection
	// but only on commands, it'll breaks larger responses with stunnel / xinetd constructs
	if req.Command != "" && !req.KeepAlive {
		p.logErrors(closeWrite(conn))
	}

	b, err := p.parseResponse(req, conn, clb)

	return b, err
}

func (p *Peer) getSocketQueryResponseWithTemporaryRetries(req *Request, query string, conn net.Conn, clb RowResultCB) ([]byte, net.Conn, error) {
	// catch temporary errors
	retries := 0
	for {
		b, err := p.getSocketQueryResponse(req, query, conn, clb)
		if err == nil {
			return b, conn, nil
		}
		if !isTemporary(err) {
			return b, conn, err
		}

		retries++
		if retries > TemporaryNetworkErrorMaxRetries {
			return nil, nil, err
		}
		if retries > 1 {
			time.Sleep(TemporaryNetworkErrorRetryDelay * time.Duration(retries-1))
		}
		peerAddr, connType := extractConnType(p.peerAddr.Get())
		conn.Close()
		var oErr error
		conn, oErr = p.openConnection(peerAddr, connType)
		if oErr != nil {
			// return both errors
			return nil, conn, fmt.Errorf("connection failed: %w, retry failed as well: %s", err, oErr.Error())
		}
	}
}

func (p *Peer) parseResponse(req *Request, conn io.ReadCloser, clb RowResultCB) (b []byte, err error) {
	// read result with fixed result size
	if req.ResponseFixed16 {
		b, err = p.parseResponseFixedSize(req, conn, clb)

		return b, err
	}

	// read result with unknown result size
	b, _, err = parseResponseUndefinedSize(conn, clb)
	if err != nil && req.Command != "" {
		// ignore errors for commands, might close connection immediately (and sending did work already...)
		logWith(p, req).Tracef("ignoring error while reading command response: %s", err.Error())
		err = nil
	}

	return b, err
}

func isTemporary(err error) bool {
	switch {
	case errors.Is(err, syscall.EAGAIN):
		// might be temporary filled send buffer, wait a couple of milliseconds and try again
		return true
	case errors.Is(err, syscall.ECONNRESET):
		// might be closed cached connection, wait and try again
		return true
	case errors.Is(err, syscall.EPIPE):
		return true
	}
	if peerErr, ok := errors.AsType[*PeerError](err); ok {
		if peerErr.srcErr != nil {
			return isTemporary(peerErr.srcErr)
		}
	}

	return false
}

func closeWrite(conn net.Conn) (err error) {
	switch c := conn.(type) {
	case *net.TCPConn:
		err = c.CloseWrite()
	case *net.UnixConn:
		err = c.CloseWrite()
	}
	if err != nil {
		err = fmt.Errorf("net.Conn.CloseWrite: %w", err)
	}

	return err
}

func (p *Peer) socketSendQuery(query string, conn net.Conn) (int, error) {
	// set read timeout
	err := conn.SetDeadline(time.Now().Add(time.Duration(p.lmd.Config.NetTimeout) * time.Second))
	if err != nil {
		return 0, fmt.Errorf("conn.SetDeadline: %w", err)
	}

	if cut, ok := strings.CutSuffix(query, "\n\n"); ok {
		written, err2 := fmt.Fprintf(conn, "%s\n", cut)
		if err2 != nil {
			return written, fmt.Errorf("socket error: %w", err2)
		}
		// send an extra newline to finish the query but ignore errors because the connection might have closed right after the query
		n2, err2 := fmt.Fprintf(conn, "\n")
		if err2 != nil {
			log.Tracef("sending final newline failed: %s", err2.Error())
		}
		written += n2

		return written, nil
	}

	n, err := fmt.Fprintf(conn, "%s", query)
	if err != nil {
		err = fmt.Errorf("socket error: %w", err)
	}

	return n, err
}

func (p *Peer) parseResponseFixedSize(req *Request, conn io.ReadCloser, clb RowResultCB) ([]byte, error) {
	header := bytes.NewBuffer(make([]byte, 0, 16))
	_, err := io.CopyN(header, conn, 16)
	resBytes := header.Bytes()
	if err != nil {
		return nil, &PeerError{msg: err.Error(), kind: ResponseError, req: req, resBytes: resBytes, srcErr: err}
	}
	for _, indicator := range connectionErrorIndicators {
		if bytes.Contains(resBytes, indicator) {
			p.logErrors(io.CopyN(header, conn, ErrorContentPreviewSize))
			resBytes = bytes.TrimSpace(header.Bytes())

			return nil, &PeerError{msg: string(resBytes), kind: ConnectionError}
		}
	}

	// response from thruk http
	if len(resBytes) > 0 && resBytes[0] == '{' {
		resBytes, conn, err = p.extractThrukHTTPResponseTriple(resBytes, conn)
		if err != nil {
			logWith(p, req).Debugf("LastQuery:")
			logWith(p, req).Debugf("%s", req.String())

			return resBytes, err
		}
	}

	code, expSize, err := parseResponseHeader(&resBytes)
	if err != nil {
		logWith(p, req).Debugf("LastQuery:")
		logWith(p, req).Debugf("%s", req.String())

		return resBytes, err
	}

	if clb != nil {
		res, totalBytes, cErr := parseResponseFixedSize(conn, clb, expSize)
		if cErr != nil {
			return res, fmt.Errorf("network read: %w", cErr)
		}

		err = p.validateResponseHeader(res, req, code, totalBytes, expSize)
		if err != nil {
			logWith(p, req).Debugf("LastQuery:")
			logWith(p, req).Debugf("%s", req.String())

			return res, err
		}

		return nil, nil
	}

	body := bytes.NewBuffer(make([]byte, 0, expSize))
	_, err = io.CopyN(body, conn, int64(expSize))
	if err != nil && errors.Is(err, io.EOF) {
		err = nil
	}

	if err != nil {
		return nil, fmt.Errorf("io.CopyN: %w", err)
	}

	res := body.Bytes()
	err = p.validateResponseHeader(res, req, code, len(res), expSize)
	if err != nil {
		logWith(p, req).Debugf("LastQuery:")
		logWith(p, req).Debugf("%s", req.String())

		return nil, err
	}

	return res, nil
}

// validateResponseHeader checks if the response header returned a valid size and return code.
func (p *Peer) validateResponseHeader(resBytes []byte, req *Request, code, totalBytes, expSize int) (err error) {
	switch code {
	case 200:
		// everything fine
	default:
		if expSize > 0 && expSize < 300 && totalBytes == expSize {
			msg := fmt.Sprintf("bad response code: %d - %s", code, string(resBytes))

			return &PeerError{msg: msg, kind: ResponseError, req: req, resBytes: resBytes, code: code}
		}
		msg := fmt.Sprintf("bad response code: %d", code)

		return &PeerError{msg: msg, kind: ResponseError, req: req, resBytes: resBytes, code: code}
	}
	if totalBytes != expSize {
		err = fmt.Errorf("bad response size, expected %d, got %d", expSize, totalBytes)

		return &PeerError{msg: err.Error(), kind: ResponseError, req: req, resBytes: resBytes, code: code}
	}

	return err
}

// GetConnection returns the next net.Conn object which answers to a connect.
// In case of a http connection, it just tries a tcp connect, but does not
// return anything.
// It returns the connection object and any error encountered.
func (p *Peer) GetConnection(req *Request) (conn net.Conn, connType ConnectionType, err error) {
	// try primary sources first
	conn, connType, err = p.tryConnection(req, p.source)
	if err == nil {
		return conn, connType, nil
	}

	// then fallback sources
	if len(p.fallback) > 0 {
		p.curPeerAddrNum.Store(0)
		p.peerAddr.Set(p.fallback[0])
		conn, connType, err = p.tryConnection(req, p.fallback)
		if err == nil {
			return conn, connType, nil
		}
	}

	return nil, ConnTypeUnix, &PeerError{msg: err.Error(), kind: ConnectionError, srcErr: err}
}

func (p *Peer) tryConnection(req *Request, source []string) (conn net.Conn, connType ConnectionType, err error) {
	for num := range source {
		var peerAddr string
		peerAddr, connType = extractConnType(p.peerAddr.Get())
		if connType == ConnTypeHTTP {
			// return ok if status is ok, don't create a new connection every time
			if p.lastHTTPRequestSuccessful.Load() {
				return conn, connType, nil
			}
		}
		conn = p.GetCachedConnection(req)
		if conn != nil {
			return conn, connType, nil
		}

		conn, err = p.openConnection(peerAddr, connType)

		// connection successful
		if err == nil {
			promPeerConnections.WithLabelValues(p.Name).Inc()
			if num > 0 {
				logWith(p).Infof("active source changed to %s", peerAddr)
				p.resetFlags()
			}

			return conn, connType, nil
		}

		// connection error
		p.setNextAddrFromErr(err, req, source)
	}

	return nil, ConnTypeUnix, err
}

func (p *Peer) openConnection(peerAddr string, connType ConnectionType) (conn net.Conn, err error) {
	switch connType {
	case ConnTypeTCP:
		logWith(p).Tracef("doing tcp connection test: %s", peerAddr)
		conn, err = net.DialTimeout("tcp", peerAddr, time.Duration(p.lmd.Config.ConnectTimeout)*time.Second)
	case ConnTypeUnix:
		logWith(p).Tracef("doing socket connection test: %s", peerAddr)
		conn, err = net.DialTimeout("unix", peerAddr, time.Duration(p.lmd.Config.ConnectTimeout)*time.Second)
	case ConnTypeTLS:
		tlsConfig, cErr := p.getTLSClientConfig()
		if cErr != nil {
			err = cErr
		} else {
			dialer := new(net.Dialer)
			dialer.Timeout = time.Duration(p.lmd.Config.ConnectTimeout) * time.Second
			logWith(p).Tracef("doing tls connection test: %s", peerAddr)
			conn, err = tls.DialWithDialer(dialer, "tcp", peerAddr, tlsConfig)
		}
	case ConnTypeHTTP:
		// test at least basic tcp connect
		uri, uErr := url.Parse(peerAddr)
		if uErr != nil {
			return nil, fmt.Errorf("url parse error: %s", uErr.Error())
		}
		host := uri.Host
		if !strings.Contains(host, ":") {
			switch uri.Scheme {
			case "http":
				host += ":80"
			case "https":
				host += ":443"
			default:
				return nil, &PeerError{msg: fmt.Sprintf("unknown scheme: %s", uri.Scheme), kind: ConnectionError}
			}
		}
		logWith(p).Tracef("doing http connection test: %s", host)
		conn, err = net.DialTimeout("tcp", host, time.Duration(p.lmd.Config.ConnectTimeout)*time.Second)
		if conn != nil {
			conn.Close()
		}
		conn = nil
	}
	if err != nil {
		logWith(p).Tracef("connection test failed: %s", err.Error())

		return nil, fmt.Errorf("connection error %w: %s", err, err.Error())
	}

	logWith(p).Tracef("connection ok")

	return conn, nil
}

// GetCachedConnection returns the next free cached connection or nil of none found.
func (p *Peer) GetCachedConnection(req *Request) (conn net.Conn) {
	pool := p.getConnectionPool()
	select {
	case conn = <-pool:
		if conn != nil {
			logWith(p, req).Tracef("using cached connection")
		} else {
			logWith(p, req).Tracef("using new connection")
		}

		return conn
	default:
		logWith(p, req).Tracef("no cached connection found")

		return nil
	}
}

// getConnectionPool returns the current connection pool channel, guarded against concurrent replacement.
func (p *Peer) getConnectionPool() chan net.Conn {
	p.cacheLock.Lock()
	defer p.cacheLock.Unlock()

	return p.cache.connectionPool
}

// putCachedConnection puts a connection (or nil) back into the current pool.
func (p *Peer) putCachedConnection(conn net.Conn) {
	pool := p.getConnectionPool()
	pool <- conn
}

func extractConnType(rawAddr string) (string, ConnectionType) {
	connType := ConnTypeUnix
	switch {
	case strings.HasPrefix(rawAddr, "http"):
		connType = ConnTypeHTTP
	case strings.HasPrefix(rawAddr, "tls://"):
		connType = ConnTypeTLS
		rawAddr = strings.TrimPrefix(rawAddr, "tls://")
	case strings.Contains(rawAddr, ":"):
		connType = ConnTypeTCP
	}

	return rawAddr, connType
}

func (p *Peer) setNextAddrFromErr(err error, req *Request, source []string) {
	if _, ok := errors.AsType[*PeerCommandError](err); ok {
		// client errors do not affect remote site status
		return
	}

	// if lmd is started in the import mode, the imported file may have unreachable peers in current execution environment
	// passthrough tables like 'log' fail their queries due to unreachable peers, ignore their errors and return early
	// otherwise the peer is set to down, and their data is removed
	if p.lmd.flags.flagImport != "" {
		return
	}

	promPeerFailedConnections.WithLabelValues(p.Name).Inc()

	peerState := p.peerState.Get()

	logContext := []any{p}
	if req != nil {
		logContext = append(logContext, req)
	}

	logWith(logContext...).Debugf("connection error %s: %s", p.peerAddr.Get(), err)
	p.lastError.Set(strings.TrimSpace(err.Error()))
	p.errorCount.Add(1)

	numSources := len(source)
	numAllSources := len(p.source) + len(p.fallback)

	// try next node if there are multiple
	nextNum := p.curPeerAddrNum.Add(1)
	if nextNum >= int64(numSources) {
		nextNum = 0
		p.curPeerAddrNum.Store(nextNum)
	}
	p.peerAddr.Set(source[nextNum])

	// invalidate connection cache
	p.resetConnectionPool()

	switch peerState {
	case PeerStatusUp, PeerStatusPending, PeerStatusSyncing:
		// only set into warning state if there is cached data
		data := p.data.Load()
		if data != nil {
			p.peerState.Set(PeerStatusWarning)
		}
	default:
		// peer state won't be updated, because it is worse than warning already
	}
	now := currentUnixTime()
	lastOnline := p.lastOnline.Get()
	logWith(logContext...).Debugf("last online: %s", timeOrNever(lastOnline))
	if lastOnline < now-float64(p.lmd.Config.StaleBackendTimeout) || (p.errorCount.Load() > int64(numAllSources) && lastOnline <= 0) {
		if peerState != PeerStatusDown && peerState != PeerStatusSyncing {
			logWith(logContext...).Infof("site state changed %s -> offline: %s", peerState.String(), err.Error())
			p.errorLogged.Store(true)
		}
		// clear existing data from memory
		p.peerState.Set(PeerStatusDown)
		p.data.Store(nil)
	}

	if numAllSources > 1 {
		logWith(logContext...).Debugf("trying next one: %s", p.peerAddr.Get())
	}
}

// resetConnectionPool closes all pooled connections and replaces the pool with a fresh
// one under lock, so concurrent readers/writers never observe a torn channel reference.
func (p *Peer) resetConnectionPool() {
	p.cacheLock.Lock()
	defer p.cacheLock.Unlock()

	old := p.cache.connectionPool
	p.cache.connectionPool = make(chan net.Conn, p.lmd.Config.MaxParallelPeerConnections)
	for {
		select {
		case conn := <-old:
			if conn != nil {
				conn.Close()
			}
		default:
			return
		}
	}
}

func (p *Peer) checkStatusFlags(ctx context.Context, store *DataStoreSet) (err error) {
	data := store.get(TableStatus).data
	if len(data) == 0 {
		return nil
	}
	row := data[0]
	livestatusVersion := row.GetStringByName("livestatus_version")
	switch {
	case len(reShinkenVersion.FindStringSubmatch(livestatusVersion)) > 0:
		if !p.hasFlag(Shinken) {
			logWith(p).Debugf("remote connection Shinken flag set")
			p.setFlag(Shinken)
		}
	case len(data) > 1:
		// getting more than one status sets the multibackend flag
		err = p.setMultiBackend(ctx, store, p.peerAddr.Get(), len(data))
		if err != nil {
			return err
		}

		return nil
	case len(reIcinga2Version.FindStringSubmatch(livestatusVersion)) > 0:
		if !p.hasFlag(Icinga2) {
			logWith(p).Debugf("remote connection Icinga2 flag set")
			p.setFlag(Icinga2)
		}
	case len(reNaemonVersion.FindStringSubmatch(livestatusVersion)) > 0:
		if !p.hasFlag(Naemon) {
			logWith(p).Debugf("remote connection Naemon flag set")
			p.setFlag(Naemon)
		}
	}

	return nil
}

func (p *Peer) setMultiBackend(ctx context.Context, store *DataStoreSet, addr string, num int) (err error) {
	if p.hasFlag(MultiBackend) {
		return nil
	}

	p.setFlag(MultiBackend)

	// if its no http connection, then it must be LMD
	if !strings.HasPrefix(addr, "http") {
		logWith(p).Infof("remote connection LMD flag set, got %d sites", num)
		p.setFlag(LMD)
	} else {
		logWith(p).Infof("remote connection MultiBackend flag set, got %d sites", num)
	}

	store.setSyncStrategy()

	// force immediate update to fetch all sites
	_, err = p.updateTick(ctx, true)
	if err != nil {
		return err
	}

	return nil
}

func (p *Peer) checkAvailableTables(ctx context.Context) (err error) {
	columnFlags := []struct { //nolint:govet // no need to align this struct, use only once
		Table  TableName
		Column string
		Flag   OptionalFlags
	}{
		{TableStatus, "localtime", HasLocaltimeColumn},
		{TableHosts, "depends_exec", HasDependencyColumn},
		{TableHosts, "lmd_last_cache_update", HasLMDLastCacheUpdateColumn},
		{TableHosts, "last_update", HasLastUpdateColumn},
		{TableHosts, "event_handler", HasEventHandlerColumn},
		{TableHosts, "staleness", HasStalenessColumn},
		{TableServices, "check_freshness", HasCheckFreshnessColumn},
		{TableServices, "parents", HasServiceParentsColumn},
		{TableContacts, "groups", HasContactsGroupColumn},
		{TableContacts, "host_notification_commands", HasContactsCommandsColumn},
	}

	if p.hasFlag(Icinga2) {
		logWith(p).Debugf("Icinga2 does not support checking tables and columns")

		return nil
	}

	availableTables := p.getSupportedColumns(ctx)

	for _, optFlag := range columnFlags {
		if _, ok := availableTables[optFlag.Table]; !ok {
			continue
		}
		if !p.hasFlag(optFlag.Flag) {
			if _, ok := availableTables[optFlag.Table][optFlag.Column]; ok {
				logWith(p).Debugf("remote connection supports %s.%s column", optFlag.Table.String(), optFlag.Column)
				p.setFlag(optFlag.Flag)
			}
		}
	}

	return nil
}

func (p *Peer) fetchThrukExtras(ctx context.Context) (conf, thrukExtras map[string]any, err error) {
	// no thruk extras on icinga2 RESTv1 backends
	if p.hasFlag(Icinga2RestV1) {
		return conf, thrukExtras, err
	}
	// no http client is a sure sign for no http connection
	if p.cache.HTTPClient == nil {
		return conf, thrukExtras, err
	}
	// try all http connections and return first config tool config
	for _, addr := range p.buildCombinedAddressList() {
		if strings.HasPrefix(addr, "http") {
			configTool, thruk, extraErr := p.fetchThrukExtrasFromAddr(ctx, addr)
			err = extraErr
			if thruk != nil {
				thrukExtras = thruk
			}
			if configTool != nil {
				conf = configTool

				return conf, thrukExtras, err
			}
		}
	}

	return conf, thrukExtras, err
}

func (p *Peer) fetchThrukExtrasFromAddr(ctx context.Context, peerAddr string) (conf, thrukExtras map[string]any, err error) {
	if !strings.HasPrefix(peerAddr, "http") {
		return conf, thrukExtras, err
	}
	options := make(map[string]any)
	options["action"] = "raw"
	options["sub"] = "get_processinfo"
	if p.config.RemoteName != "" {
		options["remote_name"] = p.config.RemoteName
	}
	optionStr, err := json.Marshal(options)
	if err != nil {
		return conf, thrukExtras, err
	}
	output, _, err := p.httpPostQuery(ctx, nil, peerAddr, url.Values{
		"data": {fmt.Sprintf("{\"credential\": %q, \"options\": %s}", p.config.Auth, optionStr)},
	}, nil, nil)
	if err != nil {
		return conf, thrukExtras, err
	}

	conf, thrukExtras, err = p.extractThrukExtrasFromResult(output)
	if err != nil {
		return conf, thrukExtras, err
	}

	return conf, thrukExtras, err
}

func (p *Peer) extractThrukExtrasFromResult(output []any) (configtool, thrukExtras map[string]any, err error) {
	if len(output) < 3 {
		return nil, nil, nil
	}
	data, ok := output[2].(map[string]any)
	if !ok {
		return nil, nil, nil
	}
	for k := range data {
		processinfo, ok := data[k].(map[string]any)
		if !ok {
			continue
		}
		if ts, ok2 := processinfo["localtime"]; ok2 {
			err := p.checkLocaltime(interface2float64(ts))
			if err != nil {
				p.setNextAddrFromErr(err, nil, p.source)

				return nil, nil, err
			}
		}
		if c, ok2 := processinfo["thruk"]; ok2 {
			if v, ok3 := c.(map[string]any); ok3 {
				thrukExtras = v
			}
		}
		if c, ok2 := processinfo["configtool"]; ok2 {
			if v, ok3 := c.(map[string]any); ok3 {
				return v, thrukExtras, nil
			}
		}
		if thrukExtras != nil {
			return nil, thrukExtras, nil
		}
	}

	return nil, nil, nil
}

func (p *Peer) buildCombinedAddressList() (list []string) {
	if len(p.config.Fallback) == 0 {
		return p.config.Source
	}

	list = make([]string, 0, len(p.config.Source)+len(p.config.Fallback))
	list = append(list, p.config.Source...)
	list = append(list, p.config.Fallback...)

	return list
}

func (p *Peer) fetchRemotePeers(ctx context.Context, store *DataStoreSet) (sites []any, err error) {
	// no remote peers on icinga2 RESTv1 backends
	if p.hasFlag(Icinga2RestV1) {
		return nil, nil
	}
	// no http client is a sure sign for no http connection
	if p.cache.HTTPClient == nil {
		return nil, nil
	}
	// we only fetch remote peers if not explicitly requested a single backend
	if p.config.RemoteName != "" {
		return nil, nil
	}
	thrukVersion := p.thrukVersion.Get()
	if thrukVersion < ThrukMultiBackendMinVersion {
		logWith(p).Warnf("remote thruk version too old (%.2f < %.2f) cannot fetch all sites.", thrukVersion, ThrukMultiBackendMinVersion)

		return nil, nil
	}

	// try all http connections and use first working connection
	for _, addr := range p.buildCombinedAddressList() {
		if !strings.HasPrefix(addr, "http") {
			continue
		}

		sites, err = p.fetchRemotePeersFromAddr(ctx, addr)
		if err != nil {
			continue
		}

		if len(sites) <= 1 {
			continue
		}

		err = p.setMultiBackend(ctx, store, addr, len(sites))
		if err != nil {
			return nil, err
		}

		return sites, nil
	}

	return nil, err
}

func (p *Peer) fetchRemotePeersFromAddr(ctx context.Context, peerAddr string) (sites []any, err error) {
	if !strings.HasPrefix(peerAddr, "http") {
		return sites, err
	}
	data, res, err := p.httpRestQuery(ctx, peerAddr, "/thruk/r/v1/sites")
	if err != nil {
		logWith(p).Warnf("rest query failed, cannot fetch all sites: %s", err.Error())

		return sites, err
	}
	if s, ok := data.([]any); ok {
		sites = s
	} else {
		err = &PeerError{msg: fmt.Sprintf("unknown site error, got: %v", res), kind: ResponseError, srcErr: err}
	}

	return sites, err
}

// WaitCondition waits for a given condition.
// It returns when the condition matches successfully or after a timeout.
func (p *Peer) WaitCondition(ctx context.Context, req *Request) {
	// wait up to one minute if nothing specified
	if req.WaitTimeout <= 0 {
		req.WaitTimeout = WaitTimeoutDefault
	}
	waitChan := make(chan struct{})
	go func(p *Peer, c chan struct{}, req *Request) {
		// make sure we log panics properly
		defer logPanicExitPeer(p)

		p.logErrors(p.waitCondition(ctx, c, req))
	}(p, waitChan, req)
	timeout := time.NewTimer(time.Duration(req.WaitTimeout) * time.Millisecond)
	select {
	case <-waitChan:
		// finished with condition met
		timeout.Stop()
	case <-timeout.C:
		// timed out
	case <-ctx.Done():
		// context closed
	}

	safeCloseWaitChannel(waitChan)
}

//nolint:gocyclo,gocognit // long but readable
func (p *Peer) waitCondition(ctx context.Context, waitChan chan struct{}, req *Request) (err error) {
	var lastUpdate float64
	for {
		select {
		case <-waitChan:
			// canceled
			return nil
		case <-ctx.Done():
			// canceled
			return nil
		default:
		}

		data, err := p.getDataStoreSet()
		if err != nil {
			time.Sleep(WaitTimeoutCheckInterval)

			continue
		}

		store, err := p.getDataStore(req.Table)
		if err != nil {
			time.Sleep(WaitTimeoutCheckInterval)

			continue
		}

		// get object to watch
		conditionOK := false
		if req.WaitObject != "" {
			obj, ok := store.GetWaitObject(req)
			if !ok {
				logWith(p, req).Warnf("WaitObject did not match any object: %s", req.WaitObject)
				safeCloseWaitChannel(waitChan)

				return nil
			}

			conditionOK = true
			for i := range req.WaitCondition {
				if !obj.MatchFilter(req.WaitCondition[i], false) {
					conditionOK = false
				}
			}
		} else if p.waitConditionTableMatches(store, req.WaitCondition) {
			conditionOK = true
		}

		// invert wait condition logic
		if req.WaitConditionNegate {
			conditionOK = !conditionOK
		}

		if conditionOK {
			// trigger update for all, wait conditions are run against the last object
			// but multiple commands may have been sent
			lastUpdate = p.lastUpdate.Get()
			p.scheduleImmediateUpdate()
			time.Sleep(WaitTimeoutCheckInterval)

			break
		}

		// nothing matched, update tables
		refreshCtx := context.TODO() // need new context, peer would be marked as failed even if just the client context finishes
		time.Sleep(WaitTimeoutCheckInterval)
		switch req.Table {
		case TableHosts:
			//nolint:contextcheck // need new context, peer would be marked as failed even if just the client context finishes
			_, _, err = data.updateDeltaHosts(refreshCtx, fmt.Sprintf("Filter: name = %s\n", req.WaitObject))
		case TableServices:
			tmp := strings.SplitN(req.WaitObject, ";", 2)
			if len(tmp) < 2 {
				logWith(p, req).Errorf("unsupported service wait object: %s", req.WaitObject)
				safeCloseWaitChannel(waitChan)

				return nil
			}
			//nolint:contextcheck // need new context, peer would be marked as failed even if just the client context finishes
			_, _, err = data.updateDeltaServices(refreshCtx, fmt.Sprintf("Filter: host_name = %s\nFilter: description = %s\n", tmp[0], tmp[1]))
		default:
			//nolint:contextcheck // need new context, peer would be marked as failed even if just the client context finishes
			err = data.updateFullTable(refreshCtx, req.Table)
		}
		if err != nil {
			if p.scheduleUpdateIfRestartRequiredError(err) {
				// backend is going to restart, wait a bit and try again
				time.Sleep(WaitTimeoutCheckInterval)
			} else {
				safeCloseWaitChannel(waitChan)

				return err
			}
		}
	}

	// waiting for final update to complete
	if lastUpdate > 0 {
		for {
			select {
			case <-waitChan:
				// canceled
				return nil
			case <-ctx.Done():
				// canceled
				return nil
			default:
			}

			// wait up to WaitTimeout till the update is complete
			if p.lastUpdate.Get() > lastUpdate {
				safeCloseWaitChannel(waitChan)

				return nil
			}
			time.Sleep(WaitTimeoutCheckInterval)

			continue
		}
	}

	return nil
}

// close channel and catch errors of already close channels.
func safeCloseWaitChannel(waitChan chan struct{}) {
	defer func() {
		if recover() != nil {
			log.Debug("close of closed channel")
		}
	}()

	close(waitChan)
}

// httpQueryWithRetries calls HTTPQuery with given amount of retries.
func (p *Peer) httpQueryWithRetries(ctx context.Context, req *Request, peerAddr, query string, retries int, clb RowResultCB) (res []byte, totalBytes int, err error) {
	res, totalBytes, err = p.httpQuery(ctx, req, peerAddr, query, clb)

	// retry on broken pipe errors
	for retry := 1; retry <= retries && err != nil; retry++ {
		logWith(p, req).Debugf("errored: %s", err.Error())
		if strings.HasPrefix(err.Error(), "remote site returned rc: 0 - ERROR: broken pipe.") {
			time.Sleep(1 * time.Second)
			res, totalBytes, err = p.httpQuery(ctx, req, peerAddr, query, clb)
			if err == nil {
				logWith(p, req).Debugf("site returned successful result after %d retries", retry)
			}
		}
	}

	return res, totalBytes, err
}

// httpQuery sends a query over http to a Thruk backend.
// It returns the livestatus answers and any encountered error.
func (p *Peer) httpQuery(ctx context.Context, req *Request, peerAddr, query string, clb RowResultCB) (res []byte, totalBytes int, err error) {
	options := make(map[string]any)
	if p.config.RemoteName != "" {
		options["backends"] = []string{p.config.RemoteName}
	}
	options["action"] = "raw"
	options["sub"] = "_raw_query"
	if p.config.RemoteName != "" {
		options["remote_name"] = p.config.RemoteName
	}
	options["args"] = []string{strings.TrimSpace(query) + "\n"}
	optionStr, err := json.Marshal(options)
	if err != nil {
		return nil, 0, fmt.Errorf("json error: %s", err.Error())
	}

	headers := make(map[string]string)
	thrukVersion := p.thrukVersion.Get()
	if thrukVersion >= ThrukMultiBackendMinVersion {
		headers["Accept"] = "application/livestatus"
	}

	output, result, err := p.httpPostQuery(ctx, req, peerAddr, url.Values{
		"data": {fmt.Sprintf("{\"credential\": %q, \"options\": %s}", p.config.Auth, optionStr)},
	}, headers, clb)
	if err != nil {
		return nil, 0, err
	}
	if clb != nil {
		return nil, 0, nil
	}
	if result.Raw != nil {
		res = result.Raw

		return res, 0, nil
	}
	if len(output) <= 2 {
		return nil, 0, &PeerError{msg: fmt.Sprintf("unknown site error, got: %#v", result), kind: ResponseError}
	}
	if v, ok := output[2].(string); ok {
		// return result string as bytes array without copying
		return unsafe.Slice(unsafe.StringData(v), len(v)), len(v), nil
	}

	return nil, 0, &PeerError{msg: fmt.Sprintf("unknown site error, got: %#v", result), kind: ResponseError}
}

// httpPostQueryResult returns response array from thruk api.
func (p *Peer) httpPostQueryResult(ctx context.Context, query *Request, peerAddr string, postData url.Values, headers map[string]string, clb RowResultCB) (result *HTTPResult, err error) { //nolint:lll // it is what it is...
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, peerAddr, strings.NewReader(postData.Encode()))
	if err != nil {
		logWith(p, query).Debugf("http(s) error: %s", fmtHTTPerr(req, err))

		return nil, fmt.Errorf("http request: %w", err)
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	p.logHTTPRequest(query, req)
	response, err := p.cache.HTTPClient.Do(req)
	if err != nil {
		p.lastHTTPRequestSuccessful.Store(false)
		logWith(p, query).Debugf("http(s) error: %s", fmtHTTPerr(req, err))
		p.logHTTPResponse(query, response, []byte{})

		return nil, fmt.Errorf("http error: %s", err.Error())
	}
	p.lastHTTPRequestSuccessful.Store(true)
	contents, err := p.extractHTTPResponse(query, response, clb)
	p.logHTTPResponse(query, response, contents)
	if err != nil {
		logWith(p, query).Debugf("http(s) error: %s", fmtHTTPerr(req, err))

		return nil, err
	}
	if clb != nil {
		return nil, nil //nolint:nilnil // in case of callbacks used, there is no result
	}

	if query != nil && query.Command != "" {
		if len(contents) == 0 || contents[0] != '{' {
			result = &HTTPResult{Raw: contents}

			return result, nil
		}
	}
	if len(contents) > 10 && bytes.HasPrefix(contents, []byte("200 ")) {
		result = &HTTPResult{Raw: contents}

		return result, nil
	}
	if len(contents) > 1 && contents[0] == '[' {
		result = &HTTPResult{Raw: contents}

		return result, nil
	}
	if len(contents) < 1 || contents[0] != '{' {
		if len(contents) > ErrorContentPreviewSize {
			contents = contents[:ErrorContentPreviewSize]
		}
		err = &PeerError{msg: fmt.Sprintf("site did not return a proper response: %s", contents), kind: ResponseError}
		logWith(p, query).Debugf("http(s) error: %s", fmtHTTPerr(req, err))

		return nil, err
	}
	err = json.Unmarshal(contents, &result)
	if err != nil {
		logWith(p, query).Debugf("http(s) error: %s", fmtHTTPerr(req, err))

		return nil, fmt.Errorf("json error: %s", err.Error())
	}
	if result.Rc != 0 {
		err = &PeerError{msg: fmt.Sprintf("remote site returned rc: %d - %s", result.Rc, result.Output), kind: ResponseError}
		logWith(p, query).Debugf("http(s) error: %s", fmtHTTPerr(req, err))

		return nil, err
	}

	return result, nil
}

// httpPostQuery returns response array from thruk api.
//
//nolint:lll // it is what it is...
func (p *Peer) httpPostQuery(ctx context.Context, req *Request, peerAddr string, postData url.Values, headers map[string]string, clb RowResultCB) (output []any, result *HTTPResult, err error) {
	result, err = p.httpPostQueryResult(ctx, req, peerAddr, postData, headers, clb)
	if err != nil {
		return nil, nil, err
	}
	if clb != nil {
		return nil, nil, nil
	}
	if result.Version != "" {
		currentVersion := p.thrukVersion.Get()
		newVersion := reThrukVersion.ReplaceAllString(result.Version, `$1`)
		thrukVersion, e := strconv.ParseFloat(newVersion, 64)
		if e == nil && currentVersion != thrukVersion {
			logWith(p, req).Debugf("remote site uses thruk version: %s", result.Version)
			p.thrukVersion.Set(thrukVersion)
		}
	}
	if result.Raw != nil {
		return nil, result, nil
	}
	err = json.Unmarshal(result.Output, &output)
	if err != nil {
		logWith(p, req).Errorf("%s", err.Error())

		return nil, nil, fmt.Errorf("json error: %s", err.Error())
	}
	if log.IsV(LogVerbosityTrace) {
		logWith(p, req).Tracef("response: %s", result.Output)
	}
	if len(output) >= 4 {
		if v, ok := output[3].(string); ok {
			remoteError := strings.TrimSpace(v)
			matched := reHTTPTooOld.FindStringSubmatch(remoteError)
			if len(matched) > 0 {
				err = &PeerError{msg: fmt.Sprintf("remote site too old: v%s - %s", result.Version, result.Branch), kind: ResponseError}
			} else {
				err = &PeerError{msg: fmt.Sprintf("remote site returned rc: %d - %s", result.Rc, remoteError), kind: ResponseError}
			}

			return nil, nil, err
		}
	}

	return output, result, nil
}

// httpRestQuery returns rest response from thruk api.
func (p *Peer) httpRestQuery(ctx context.Context, peerAddr, uri string) (output any, result *HTTPResult, err error) {
	options := make(map[string]any)
	options["action"] = "url"
	options["commandoptions"] = []string{uri}
	optionStr, err := json.Marshal(options)
	if err != nil {
		return nil, nil, fmt.Errorf("json error: %s", err.Error())
	}
	result, err = p.httpPostQueryResult(ctx, nil, peerAddr, url.Values{
		"data": {fmt.Sprintf("{\"credential\": %q, \"options\": %s}", p.config.Auth, optionStr)},
	}, map[string]string{"Accept": "application/json"}, nil)
	if err != nil {
		return nil, nil, err
	}
	if result.Code >= http.StatusBadRequest {
		return nil, nil, fmt.Errorf("%d: %s", result.Code, result.Message)
	}
	if result.Raw != nil {
		err = json.Unmarshal(result.Raw, &output)
		if err != nil {
			return nil, nil, fmt.Errorf("json error: %s", err.Error())
		}

		return output, result, nil
	}
	var str string
	err = json.Unmarshal(result.Output, &str)
	if err != nil {
		return nil, nil, fmt.Errorf("json error: %s", err.Error())
	}
	err = json.Unmarshal([]byte(str), &output)
	if err != nil {
		return nil, nil, fmt.Errorf("json error: %s", err.Error())
	}

	return output, result, nil
}

// extractHTTPResponse returns the content of a HTTP request.
func (p *Peer) extractHTTPResponse(req *Request, response *http.Response, clb RowResultCB) (contents []byte, err error) {
	if clb != nil && response.StatusCode == http.StatusOK {
		contents, err = p.parseResponse(req, response.Body, clb)
		if err != nil {
			return contents, fmt.Errorf("io error: %s", err.Error())
		}
	} else {
		contents, err = io.ReadAll(response.Body)
		if err != nil {
			return contents, fmt.Errorf("io error: %s", err.Error())
		}
	}

	_, err = io.Copy(io.Discard, response.Body)
	if err != nil {
		return nil, fmt.Errorf("io error: %s", err.Error())
	}

	err = response.Body.Close()
	if err != nil {
		return nil, fmt.Errorf("io error: %s", err.Error())
	}

	if response.StatusCode == http.StatusOK {
		return contents, nil
	}

	matched := reHTTPOMDError.FindStringSubmatch(string(contents))
	if len(matched) > 1 {
		return nil, &PeerError{msg: fmt.Sprintf("http request failed: %s - %s", response.Status, matched[1]), kind: ResponseError}
	}
	matched = reHTTPThrukError.FindStringSubmatch(string(contents))
	if len(matched) > 1 {
		return nil, &PeerError{msg: fmt.Sprintf("http request failed: %s - %s", response.Status, matched[1]), kind: ResponseError}
	}

	return nil, &PeerError{msg: fmt.Sprintf("http request failed: %s", response.Status), kind: ResponseError}
}

// passThroughQuery runs a passthrough query on a single peer and appends the result.
func (p *Peer) passThroughQuery(ctx context.Context, res *Response, passthroughRequest *Request, virtualColumns []*Column, columnsIndex map[*Column]int) {
	req := res.request
	// do not use Query here, might be a log query with log
	result, _, queryErr := p.query(ctx, passthroughRequest)
	logWith(p, req).Tracef("req done")
	if queryErr != nil {
		var peerErr *PeerError
		if !errors.As(queryErr, &peerErr) || peerErr.kind != ResponseError {
			// connection issue, need to reset current connection
			p.setNextAddrFromErr(queryErr, passthroughRequest, p.source)
		}
		logWith(p, req).Tracef("passthrough req errored %s", queryErr.Error())
		res.lock.Lock()
		res.failed[p.ID] = queryErr
		res.lock.Unlock()

		return
	}
	// insert virtual values, like peer_addr or name
	if len(virtualColumns) > 0 {
		table := Objects.Tables[res.request.Table]
		store := NewDataStore(table, p)
		tmpRow, _ := NewDataRow(store, nil, nil, 0, true)
		for rowNum := range result {
			row := &result[rowNum]
			for j := range virtualColumns {
				col := virtualColumns[j]
				i := columnsIndex[col]
				*row = append(*row, 0)
				copy((*row)[i+1:], (*row)[i:])
				(*row)[i] = tmpRow.GetValueByColumn(col)
			}
			result[rowNum] = *row
		}
	}
	logWith(p, req).Tracef("result ready")
	res.lock.Lock()
	if len(req.Stats) == 0 {
		res.result = append(res.result, result...)
	} else {
		if res.request.StatsResult == nil {
			res.request.StatsResult = NewResultSetStats()
		}
		// apply stats queries
		numCol := len(res.request.RequestColumns)
		totalCols := numCol + len(res.request.Stats)
		for i := range result {
			row := result[i]
			if len(row) != totalCols {
				log.Errorf("invalid result row, expected %d columns and got %d", totalCols, len(row))

				continue
			}
			keyValues := []string{}
			for j := range res.request.RequestColumns {
				keyValues = append(keyValues, interface2stringNoDedup(row[j]))
			}
			key := strings.Join(keyValues, ListSepChar1)

			if _, ok := res.request.StatsResult.Stats[key]; !ok {
				res.request.StatsResult.Stats[key] = createLocalStatsCopy(res.request.Stats)
			}
			for j := range req.Stats {
				val := interface2float64(row[numCol+j])
				res.request.StatsResult.Stats[key][j].ApplyValue(val, 1)
			}
		}
	}
	res.lock.Unlock()
}

// isOnline returns true if this peer is online.
func (p *Peer) isOnline() bool {
	return p.hasPeerState([]PeerStatus{PeerStatusUp, PeerStatusWarning})
}

// hasPeerState returns true if this peer has given state.
func (p *Peer) hasPeerState(states []PeerStatus) bool {
	status := p.peerState.Get()
	if p.hasFlag(LMDSub) {
		realStatus := p.subPeerStatus.Load()
		if realStatus == nil {
			return false
		}
		num, ok := (*realStatus)["status"]
		if !ok {
			return false
		}
		status = PeerStatus(interface2int8(num))
	}

	return slices.Contains(states, status)
}

func (p *Peer) getError() string {
	if !p.hasFlag(LMDSub) {
		return p.lastError.Get()
	}

	realStatus := p.subPeerStatus.Load()
	if realStatus != nil {
		errString, ok := (*realStatus)["last_error"]
		if ok {
			str := interface2stringNoDedup(errString)
			if str != "" {
				return str
			}
		}
	}

	return p.lastError.Get()
}

func (p *Peer) waitConditionTableMatches(store *DataStore, filter []*Filter) bool {
Rows:
	for j := range store.data {
		row := store.data[j]
		// does our filter match?
		for _, f := range filter {
			if !row.MatchFilter(f, false) {
				continue Rows
			}
		}

		return true
	}

	return false
}

func (p *Peer) clearLastRequest() {
	if !p.lmd.Config.SaveTempRequests {
		return
	}
	p.last.Request.Store(nil)
	p.last.Response.Store(nil)
}

func (p *Peer) setBroken(details string) {
	details = strings.TrimSpace(details)
	logWith(p).Warnf("%s", details)
	p.peerState.Set(PeerStatusBroken)
	p.lastError.Set("broken: " + details)
	p.thrukVersion.Set(-1)
	p.data.Store(nil)
}

func logPanicExitPeer(peer *Peer) {
	details := recover()
	if details == nil {
		return
	}

	log := logWith(peer, peer.last.Request.Load())
	log.Errorf(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
	log.Errorf("Panic:                 %s", details)
	log.Errorf("LMD Version:           %s", Version())
	peer.logPeerStatus(log.Errorf)
	log.Errorf("Stacktrace:\n%s\n%s", details, debug.Stack())
	if peer.last.Request.Load() != nil {
		log.Errorf("LastQuery:")
		log.Errorf("%s", peer.last.Request.Load().String())
	}
	if peer.last.Response.Load() != nil {
		log.Errorf("LastResponse:")
		log.Errorf("%s", string(*peer.last.Response.Load()))
	}
	logThreaddump()
	deletePidFile(peer.lmd.flags.flagPidfile)
	log.Errorf("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<")
	os.Exit(1)
}

func (p *Peer) logPeerStatus(logger func(string, ...any)) {
	peerFlags := OptionalFlags(atomic.LoadUint32(&p.flags))
	peerState := p.peerState.Get()
	logger("PeerAddr:              %s", p.peerAddr.Get())
	logger("Idling:                %v", p.idling.Load())
	logger("Paused:                %v", p.paused.Load())
	logger("ResponseTime:          %.3fs", p.responseTime.Get())
	logger("LastUpdate:            %.3f", p.lastUpdate.Get())
	logger("LastFullUpdate:        %.3f", p.lastFullUpdate.Get())
	logger("LastQuery:             %.3f", p.lastQuery.Get())
	logger("Peerstatus:            %s", peerState.String())
	logger("Flags:                 %s", peerFlags.String())
	logger("LastError:             %s", p.lastError.Get())
	logger("ErrorCount:            %d", p.errorCount.Load())
}

func (p *Peer) getTLSClientConfig() (*tls.Config, error) {
	config := getMinimalTLSConfig(p.lmd.Config)
	if p.config.TLSCertificate != "" && p.config.TLSKey != "" {
		cer, err := tls.LoadX509KeyPair(p.config.TLSCertificate, p.config.TLSKey)
		if err != nil {
			return nil, fmt.Errorf("tls.LoadX509KeyPair %s / %s: %w", p.config.TLSCertificate, p.config.TLSKey, err)
		}
		config.Certificates = []tls.Certificate{cer}
	}

	if p.config.TLSSkipVerify > 0 || p.lmd.Config.SkipSSLCheck > 0 {
		config.InsecureSkipVerify = true
	}

	if p.config.TLSCA != "" {
		caCert, err := os.ReadFile(p.config.TLSCA)
		if err != nil {
			return nil, fmt.Errorf("readfile %s: %w", p.config.TLSCA, err)
		}
		caCertPool := x509.NewCertPool()
		caCertPool.AppendCertsFromPEM(caCert)
		config.RootCAs = caCertPool
	}
	config.ServerName = p.config.TLSServerName

	return config, nil
}

// sendCommandsWithRetry sends list of commands and retries until the peer is completely down.
func (p *Peer) sendCommandsWithRetry(ctx context.Context, commands []string) (err error) {
	ctx = context.WithValue(ctx, CtxPeer, p.Name)
	p.lastQuery.Set(currentUnixTime())
	if p.idling.Load() {
		p.idling.Store(false)
		logWith(ctx).Infof("switched back to normal update interval")
	}

	// check status of backend
	retries := 0
	for {
		status := p.peerState.Get()
		switch status {
		case PeerStatusDown:
			logWith(ctx).Debugf("cannot send command, peer is down")

			return &PeerCommandError{
				code: ReturnCodeConnectionError,
				peer: p,
				err:  fmt.Errorf("cannot send command, peer is down"),
			}
		case PeerStatusBroken:
			logWith(ctx).Debugf("cannot send command, peer is broken")

			return &PeerCommandError{
				code: ReturnCodeConnectionError,
				peer: p,
				err:  fmt.Errorf("cannot send command, peer is broken"),
			}
		case PeerStatusWarning, PeerStatusPending:
			// wait till we get either a up or down
			time.Sleep(1 * time.Second)
		case PeerStatusUp, PeerStatusSyncing:
			err = p.SendCommands(ctx, commands)
			if err == nil {
				return nil
			}

			var peerErr *PeerError
			var peerCmdErr *PeerCommandError
			switch {
			case errors.As(err, &peerErr):
				// connection error, try again
				if peerErr.kind == ConnectionError {
					if retries > 0 {
						/* this indicates a problem with the command itself:
						   the peer is up, we send a command -> peer is down
						   then peer comes up again, we send the command again
						   and the peer is immediately down again. This means
						   the command probably worked, but something else failed,
						   so don't repeat the command in an endless loop
						*/
						return peerErr
					}
					retries++
					time.Sleep(1 * time.Second)

					continue
				}
			case errors.As(err, &peerCmdErr):
				return peerCmdErr
			}

			return &PeerCommandError{
				code: ReturnCodeConnectionError,
				peer: p,
				err:  fmt.Errorf("%s", p.lastError.Get()),
			}
		default:
			logWith(ctx).Panicf("PeerStatus %v not implemented", status)
		}
	}
}

func commandsAffectCommentsOrDowntimes(commands []string) bool {
	for _, cmd := range commands {
		cmdName, _, found := strings.Cut(cmd, ";")
		if !found {
			continue
		}
		switch {
		case strings.Contains(cmdName, "DOWNTIME"):
			return true
		case strings.Contains(cmdName, "COMMENT"):
			return true
		case strings.Contains(cmdName, "ACKNOWLEDGE"):
			return true
		}
	}

	return false
}

// setFederationInfo updates federation information for /site request.
func (p *Peer) setFederationInfo(data map[string]any, target *atomicStringList, dataKey string) {
	if _, ok := data["federation_"+dataKey]; ok {
		if v, ok := data["federation_"+dataKey].([]any); ok {
			list := make([]string, 0, len(v))
			for _, d := range v {
				s := interface2stringNoDedup(d)
				if dataKey == "addr" {
					s = strings.TrimSuffix(s, "/thruk/cgi-bin/remote.cgi")
				}
				list = append(list, s)
			}
			target.Set(list)

			return
		}
	}
	if v, ok := data[dataKey].(string); ok {
		target.Set([]string{v})

		return
	}
	target.Set([]string{})
}

// hasFlag returns true if flags are present.
func (p *Peer) hasFlag(flag OptionalFlags) bool {
	if flag == 0 {
		return true
	}
	f := OptionalFlags(atomic.LoadUint32(&p.flags))

	return f.HasFlag(flag)
}

// setFlag set a flag.
func (p *Peer) setFlag(flag OptionalFlags) {
	f := OptionalFlags(atomic.LoadUint32(&p.flags))
	f |= flag
	atomic.StoreUint32(&p.flags, uint32(f))
}

// resetFlags removes all flags and sets the initial flags from config.
func (p *Peer) resetFlags() {
	atomic.StoreUint32(&p.flags, uint32(NoFlags))

	// add default flags
	for _, flag := range p.config.Flags {
		switch strings.ToLower(flag) {
		case "icinga2":
			logWith(p).Debugf("remote connection Icinga2 flag set")
			p.setFlag(Icinga2)
		case "icinga2-restv1":
			logWith(p).Debugf("remote connection Icinga2RestV1 flag set")
			p.setFlag(Icinga2)
			p.setFlag(Icinga2RestV1)
		default:
			if p.lmd.flags.flagImport == "" {
				logWith(p).Warnf("unknown flag: %s", flag)
			}
		}
	}
}

// getDataStore returns store for given name or error if peer is offline.
func (p *Peer) getDataStore(tableName TableName) (store *DataStore, err error) {
	table := Objects.Tables[tableName]
	if table.virtual != nil {
		store = table.virtual(table, p)
		if store == nil {
			return nil, fmt.Errorf("peer is down: %s", p.getError())
		}

		return store, nil
	}
	data, err := p.getDataStoreSet()
	if err != nil {
		return nil, err
	}

	store = data.get(tableName)
	if store != nil {
		return store, nil
	}

	return nil, fmt.Errorf("peer is down: %s", p.getError())
}

// getSupportedColumns returns a list of supported columns.
func (p *Peer) getSupportedColumns(ctx context.Context) (tables map[TableName]map[string]bool) {
	req := &Request{
		Table:   TableColumns,
		Columns: []string{"table", "name"},
	}
	p.setQueryOptions(req)
	res, _, err := p.query(ctx, req) // skip default error handling here
	if err != nil {
		if strings.Contains(err.Error(), "Table 'columns' does not exist") {
			return tables
		}
		// not a fatal error, we can assume safe defaults
		logWith(p, req).Warnf("fetching available columns failed: %w", err)

		return tables
	}
	tables = make(map[TableName]map[string]bool)
	for _, row := range res {
		table := interface2stringNoDedup(row[0])
		tableName, e := NewTableName(table)
		if e != nil {
			continue
		}
		column := interface2stringNoDedup(row[1])
		if _, ok := tables[tableName]; !ok {
			tables[tableName] = make(map[string]bool)
		}
		tables[tableName][column] = true
	}

	return tables
}

// setQueryOptions sets common required query options.
func (p *Peer) setQueryOptions(req *Request) {
	if req.Command == "" {
		req.KeepAlive = p.lmd.Config.BackendKeepAlive
		req.ResponseFixed16 = true
		req.OutputFormat = OutputFormatJSON
	}
	if p.parentID != "" && p.hasFlag(LMDSub) {
		req.Backends = []string{p.ID}
	}
}

// getDataStoreSet returns table data or error.
func (p *Peer) getDataStoreSet() (store *DataStoreSet, err error) {
	store = p.data.Load()
	if store == nil {
		err = fmt.Errorf("peer is down: %s", p.getError())
	}

	return store, err
}

func (p *Peer) resumeFromIdle(ctx context.Context) (err error) {
	data := p.data.Load()
	state := p.peerState.Get()
	p.idling.Store(false)
	logWith(p).Infof("switched back to normal update interval")
	if state == PeerStatusUp && data != nil {
		logWith(p).Debugf("spin up update")

		if iErr := data.resumeFromIdle(ctx); iErr != nil {
			return iErr
		}
		logWith(p).Debugf("spin up update done")
	} else {
		// force new update sooner
		p.scheduleImmediateUpdate()
	}

	return err
}

func (p *Peer) requestLocaltime(ctx context.Context) (err error) {
	if !p.hasFlag(HasLocaltimeColumn) {
		return nil
	}
	req := &Request{
		Table:   TableStatus,
		Columns: []string{"localtime"},
	}
	p.setQueryOptions(req)
	res, _, err := p.Query(ctx, req)
	if err != nil {
		return err
	}
	if len(res) == 0 || len(res[0]) == 0 {
		return err
	}
	unix := interface2float64(res[0][0])
	err = p.checkLocaltime(unix)
	if err != nil {
		p.setNextAddrFromErr(err, req, p.source)
	}

	return err
}

func (p *Peer) checkLocaltime(unix float64) (err error) {
	if unix == 0 {
		return nil
	}

	nanoseconds := int64((unix - float64(int64(unix))) * float64(time.Second))
	ts := time.Unix(int64(unix), nanoseconds)
	diff := time.Since(ts)
	logWith(p).Debugf("clock difference: %s", diff.Truncate(time.Millisecond).String())
	if p.lmd.Config.MaxClockDelta > 0 && math.Abs(diff.Seconds()) > p.lmd.Config.MaxClockDelta {
		return fmt.Errorf("clock error, peer is off by %s (threshold: %vs)", diff.Truncate(time.Millisecond).String(), p.lmd.Config.MaxClockDelta)
	}

	return err
}

// logErrors i a generic error logger with peer prefix.
func (p *Peer) logErrors(v ...any) {
	if !log.IsV(LogVerbosityDebug) {
		return
	}
	logWith(p).LogErrors(v...)
}

func (p *Peer) checkBackendRestarted(primaryKeysLen int, res ResultSet, columns ColumnList) (err error) {
	if p.hasFlag(MultiBackend) {
		return nil
	}
	if len(res) != 1 {
		return nil
	}

	corePid := p.corePid.Load()

	// not yet started completely
	if p.programStart.Load() == 0 || corePid == 0 {
		return nil
	}

	if len(res[0]) != len(columns)+primaryKeysLen {
		return nil
	}

	newProgramStart := int64(0)
	newCorePid := int64(0)
	for i, col := range columns {
		switch col.Name {
		case "program_start":
			newProgramStart = interface2int64(res[0][i+primaryKeysLen])
		case "nagios_pid":
			newCorePid = interface2int64(res[0][i+primaryKeysLen])
		}
	}

	if newProgramStart != p.programStart.Load() || newCorePid != corePid {
		err = fmt.Errorf("site has been restarted, recreating objects (program_start: %d, pid: %d)", newProgramStart, newCorePid)
		if !p.errorLogged.Load() {
			logWith(p).Infof("%s", err.Error())
			p.errorLogged.Store(true)
		}

		return &PeerError{msg: err.Error(), kind: RestartRequiredError}
	}

	return nil
}

// addSubPeer adds new/existing lmd/http sub federated peer.
func (p *Peer) addSubPeer(ctx context.Context, subFlag OptionalFlags, key, subName string, data map[string]any) (subID string) {
	subID = key
	subPeer := p.lmd.peerMap.Get(subID)
	duplicate := ""
	if subPeer != nil {
		logWith(p).Tracef("already got a sub peer for id %s", subPeer.ID)
		if subPeer.hasFlag(subFlag) {
			// update flags for existing sub peers
			subPeer.subPeerStatus.Store(&data)

			return subID
		}

		// create dummy peer which is disabled and only shows this error
		duplicate = fmt.Sprintf("federate site %s/%s id clash %s already taken", p.Name, subName, subID)
		subID += "dup"
		subPeer = p.lmd.peerMap.Get(subID)
		if subPeer != nil {
			return subID
		}
	}

	logWith(p).Debugf("starting sub peer for %s, id: %s", subName, subID)
	conn := Connection{
		ID:             subID,
		Name:           subName,
		Source:         p.source,
		Fallback:       p.fallback,
		RemoteName:     subName,
		TLSCertificate: p.config.TLSCertificate,
		TLSKey:         p.config.TLSKey,
		TLSCA:          p.config.TLSCA,
		TLSSkipVerify:  p.config.TLSSkipVerify,
		Auth:           p.config.Auth,
	}
	subPeer = NewPeer(p.lmd, &conn)
	subPeer.parentID = p.ID
	subPeer.setFlag(subFlag)
	subPeer.peerParent = p.ID
	subPeer.subPeerStatus.Store(&data)
	section := ""

	switch subFlag {
	case HTTPSub:
		section = interface2stringNoDedup(data["section"])
		subPeer.setFederationInfo(data, &subPeer.subKey, "key")
		subPeer.setFederationInfo(data, &subPeer.subName, "name")
		subPeer.setFederationInfo(data, &subPeer.subAddr, "addr")
		subPeer.setFederationInfo(data, &subPeer.subType, "type")
		subPeer.setFederationInfo(data, &subPeer.subVersion, "version")

	case LMDSub:
		// try to fetch section information
		// may fail for older lmd versions
		req := &Request{
			Table:   TableSites,
			Columns: []string{"section"},
		}
		subPeer.setQueryOptions(req)
		res, _, err := subPeer.query(ctx, req)
		if err == nil {
			section = interface2stringNoDedup(res[0][0])
		}
	default:
		log.Panicf("sub flag %#v not supported", subFlag)
	}

	section = strings.TrimPrefix(section, "Default")
	section = strings.TrimPrefix(section, "/")
	subPeer.section = section

	p.lmd.peerMap.Add(subPeer)
	p.lmd.nodeAccessor.assignedBackends = append(p.lmd.nodeAccessor.assignedBackends, subID)

	if !p.paused.Load() {
		subPeer.Start(ctx)
	}
	if duplicate != "" {
		subPeer.Stop()
		subPeer.setBroken(duplicate)
	}

	return subID
}

// trace log http request.
func (p *Peer) logHTTPRequest(query *Request, req *http.Request) {
	if log.IsV(LogVerbosityTrace) {
		requestBytes, err := httputil.DumpRequest(req, true)
		if err != nil {
			logWith(p, query).Debugf("failed to dump http request: %s", fmtHTTPerr(req, err))
		}
		logWith(p, query).Tracef("***************** HTTP Request *****************")
		logWith(p, query).Tracef("%s", string(requestBytes))
	}
}

// trace log http response.
func (p *Peer) logHTTPResponse(query *Request, res *http.Response, contents []byte) {
	if res == nil {
		return
	}

	if !log.IsV(LogVerbosityTrace) {
		return
	}

	logWith(p, query).Tracef("***************** HTTP Response *****************")
	responseBytes, err := httputil.DumpResponse(res, len(contents) == 0)
	if err != nil {
		logWith(p, query).Debugf("failed to dump http response: %s", err)
	}
	if len(contents) > 0 {
		responseBytes = append(responseBytes, contents...)
	}
	contents, err = io.ReadAll(res.Body)
	if err == nil {
		responseBytes = append(responseBytes, contents...)
	}

	logWith(p, query).Tracef("%s", string(responseBytes))
}

// extra json data from cli response
// returns the actual header along with the json data as bytes.
func (p *Peer) extractThrukHTTPResponseTriple(headerBytes []byte, conn io.ReadCloser) (data []byte, readBuffer io.ReadCloser, err error) {
	data, err = io.ReadAll(conn)
	if err != nil && errors.Is(err, io.EOF) {
		err = nil
	}
	if err != nil {
		return nil, nil, err
	}

	combined := make([]byte, 0, len(headerBytes)+len(data))
	combined = append(combined, headerBytes...)
	combined = append(combined, data...)

	result := &HTTPResult{}
	err = json.Unmarshal(combined, &result)
	if err != nil {
		return nil, nil, fmt.Errorf("json error: %s", err.Error())
	}

	output := []any{}
	err = json.Unmarshal(result.Output, &output)
	if err != nil {
		return nil, nil, fmt.Errorf("json error: %s", err.Error())
	}

	if len(output) < 3 {
		if len(combined) > ErrorContentPreviewSize {
			combined = combined[:ErrorContentPreviewSize]
		}

		return nil, nil, fmt.Errorf("unknown result format: %s", combined)
	}

	if rawJSON, ok := output[2].(string); ok {
		if len(rawJSON) <= 16 {
			if len(combined) > ErrorContentPreviewSize {
				combined = combined[:ErrorContentPreviewSize]
			}

			return nil, nil, fmt.Errorf("unknown result format: %s", combined)
		}

		newHeader := []byte(rawJSON)[0:16]
		data = []byte(rawJSON)[16:]

		return newHeader, io.NopCloser(bytes.NewReader(data)), nil
	}

	if len(combined) > ErrorContentPreviewSize {
		combined = combined[:ErrorContentPreviewSize]
	}

	return nil, nil, fmt.Errorf("unknown result format: %s", combined)
}

// response can either be a plain error, ex.: "400: unknown command" or
// a json response, ex.: {"failed": {"peerID":"400: command broken"}}.
func (p *Peer) parseCommandErrResponse(response string) error {
	response = strings.TrimSpace(response)

	// this looks like a json response
	if strings.HasPrefix(response, "{") {
		failed := struct {
			Failed map[string]string `json:"failed"`
		}{}
		err := json.Unmarshal([]byte(response), &failed)
		if err != nil {
			log.Errorf("failed to decode response: %s", err)

			return fmt.Errorf("%s", response)
		}

		msg, ok := failed.Failed[p.ID]
		if !ok {
			return fmt.Errorf("%s", response)
		}

		// extract message from json error and continue with normal parsing
		response = msg
	}

	// parse from a string response, ex.: "400: unknown command"
	tmp := strings.SplitN(strings.TrimSpace(response), ":", 2)
	if len(tmp) == 2 {
		code, _ := strconv.Atoi(tmp[0])

		return &PeerCommandError{err: fmt.Errorf("%s", strings.TrimSpace(tmp[1])), code: code, peer: p}
	}

	// fallback to string only error
	return fmt.Errorf("%s", response)
}
